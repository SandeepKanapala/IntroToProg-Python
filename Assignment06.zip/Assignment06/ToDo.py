# -------------------------------------------------#
# Title: daily To-Do tasks using classes and methods
# Dev:   RRoot
# Date:  December 08, 2018
# ChangeLog: (Who, When, What)
#   RRoot, 11/02/2016, Created starting template
#   SandeepK, 12/08/2018, Added code to complete assignment 6
# -------------------------------------------------#

# -- Data --#
# declare variables and constants
# objFile = An object that represents a file
# strData = A row of text data from the file
# dicRow = A row of data separated into elements of a dictionary {Task,Priority}
# lstTable = A dictionary that acts as a 'table' of rows
# strMenu = A menu of user options
# strChoice = Capture the user option selection

# -- Input/Output --#
# User can see a Menu (Step 2)
# User can see data (Step 3)
# User can insert or delete data(Step 4 and 5)
# User can save to file (Step 6)

# -- Processing --#
# Step 1
# When the program starts, load the any data you have
# in a text file called ToDo.txt into a python Dictionary.

# Step 2
# Display a menu of choices to the user

# Step 3
# Display all todo items to user

# Step 4
# Add a new item to the list/Table

# Step 5
# Remove a new item to the list/Table

# Step 6
# Save tasks to the ToDo.txt file

# Step 7
# Exit program
# -------------------------------


FileName = open("ToDo.txt", "a")
strData = ""
dicRow = {}
lstTaskTable = []
# Step 1 - Load data from a file
# When the program starts, load each "row" of data in ToDo.txt into a python Dictionary.
File = open("ToDo.txt", "r")
for item in File:
    strData = item.split(",")
    dicRow = {"Task":strData[0].strip(), "Priority":strData[1].strip()}
    lstTaskTable.append(dicRow)
File.close()

#creating a class
class ToDoList(object):
    #creating first method to show the current task list
    @staticmethod
    def DisplayTasks():
        print("Here is the current task list: ")
        for myTasks in lstTaskTable:
            print(myTasks['Task'] + '-' + myTasks['Priority'])  # evaluates and prints the task list
        # end of first method
    # creating second methods to add a new task
    @staticmethod
    def AddNewTask(task,priority):
        strTaskName = input("Enter a Task Name: ")
        strPriority = input("Enter the Priority: ")
        dicNewTaskRow = {"Task": strTaskName, "Priority": strPriority}
        lstTaskTable.append(dicNewTaskRow) #adds the new added task to the lstTaskTable
        #end of second method
    # creating third method to remove the task from the task list.
    @staticmethod
    def RemoveTask(task, priority):
        taskToRemove = input("Which Task would you like to remove? :")
        removedTask = False
        rowToRemove = 0
        while(rowToRemove < len(lstTaskTable)):
            if(taskToRemove == str(list(dict(lstTaskTable[rowToRemove]).values())[0])): # values funcation creates a list
                del lstTaskTable[rowToRemove]
                removedTask = True
            rowToRemove = rowToRemove + 1 # increments the rowToRemove
        if(removedTask == True):
            print("Task", "'", str(taskToRemove),"'", "has been removed!") #evaluates and prints when task is removed.
        else:
            print("Task is not listed in the ToDo list!")
        # end of third method

# Step 2 - Display a menu of choices to the user
while (True):
    print("""
    Menu of Options
    1) Show current data
    2) Add a new item.
    3) Remove an existing item.
    4) Save Data to File
    5) Exit Program
    """) #prints this menu to the user
    strChoice = str(input("Which option would you like to perform? [1 to 4] - "))
    print()

    # Step 3 -Show the current items in the table
    if (strChoice.strip() == '1'):
        ToDoList.DisplayTasks()
        continue
    # Step 4 - Add a new item to the list/Table
    elif (strChoice.strip() == '2'):
        ToDoList.AddNewTask(task="",priority="")
        ToDoList.DisplayTasks()
        continue
    # Step 5 - Remove a new item to the list/Table
    elif (strChoice == '3'):
        ToDoList.RemoveTask(task="",priority="")
        ToDoList.DisplayTasks()
        continue
    # Step 6 - Save tasks to the ToDo.txt file
    elif (strChoice == '4'):
        objFileName = open("ToDo.txt", "w")
        for lineItem in lstTaskTable:
            objFileName.write(lineItem["Task"] + "," + lineItem["Priority"] + "\n")
        objFileName.close()
        ToDoList.DisplayTasks()
        print("The above task list is saved to a data file at path location C:\_PythonClass\Assignment06\ToDo.txt!!!")
        continue
    elif (strChoice == '5'):
        break  # and Exit the program