#-------------------------------------------------#
# Title: Working with Lists
# Dev:   RRoot
# Date:  Jul 25, 2016
# ChangeLog: (Who, When, What)
#   none yet
#-------------------------------------------------#

#1) A list and a dictionaries are very similar
#   but dictionaries use "keys" instead of indexes
lstRow1 = ["1","Bob Smith", "BSmith@Hotmail.com"]
dicRow1 = {"ID":1,"Name":"Bob Smith", "Email":"BSmith@Hotmail.com"}
print(lstRow1)
print(dicRow1)

print(lstRow1[1])
print(dicRow1["Name"])

#2) dictionaries should can be nested (multi-dimensional),
#   but may also be placed in a list to keep things simple.
print("\n--- multi-dimensional list")
dicRow2 = {"ID":"2","Name":"Sue Jones", "Email":"SueJ@Yahoo.com"}
lstTable = [dicRow1, dicRow2]
print(lstTable)

#3) You can loop through the list to see you dictionary objects
print("\n--- items in the list 'Table'")
for objRow in lstTable:
 print(objRow)

#4) Dictionaries have a number extra functions and properties
#4a) items()
print("\n--- items()")
for myKey, myValue in dicRow1.items():
 print(myKey, " = ", myValue )

#4b) values()
print("\n--- values()")
print(dicRow1.values())

#4b) keys()
print("\n--- keys()")
print(dicRow1.keys())

#5) remove
print("\n--- remove()")
lstEx = [1, 'one', 2, 'two', 3, 5, 'add']
lstEx.remove('one')
print(lstEx)


'Clean House', 'low'