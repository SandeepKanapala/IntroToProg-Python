# Create an application that uses a list to hold the following data:
# Id	Name	Email
# 1	Bob Smith	BSmith@Hotmail.com
# 2	Sue Jones	SueJ@Yahoo.com
# 3	Joe James	JoeJames@Gmail.com
# Add code that lets users appends a new row of data.
# Add a loop that lets the user keep adding rows.
# Ask the user if they want to save the data to a file when they exit the loop.
# Save the data to a file if they say 'yes'

# Create an application that uses a list to hold the following data:
lstRow0 = [1,"Bob Smith","BSmith@Hotmail.com"]
lstRow01 = [2, 'Sue Jones', 'SueJ@Yahoo.com']
lstRow02 = [3, 'Joe James','JJames@gmail.com']
lstTable = [lstRow0,lstRow01,lstRow02]
# Add a loop that lets the user keep adding rows.
while(True):
    strId = int(input("Enter the ID: "))
    strName = input("Enter a Name: ")
    strEmail = input("Enter an email: ")
    lstNewRow = [strId,strName,strEmail]
# Add code that lets users appends a new row of data.
    lstTable.append(lstNewRow)
    if(input("Type 'exit' to end the program?").lower() == "exit"):break
# Ask the user if they want to save the data to a file when they exit the loop.
# Save the data to a file if they say 'yes'
strSavedata = input("Do you want to save the data to a file? (y/n)")
if(strSavedata.lower() == 'y'):
    ObjF = open("Lab05-01.data", "a")
    ObjF.write(str(lstTable))
    ObjF.close
    print("Date saved to file", lstTable)
else:
    print("Data not saved!!!!")


