# Author: MyName
# When: 12/13/2018
# Purpose: Assignment 07
#-------------------------------------------------------------------------------

#1. Get data from the user
#2. Check if the data entered is a number
#3. if the entered data is not number inform the user that its not a number.
#4. If the entered data is a number inform the user that its a number.

#-------------------------------------------------------------------------------


storeData = None
#1. Get data from the user
try:
    storeData = int(input("Enter a number:")) #asking user to enter a number
#2. Check if the data entered is a number
except:
    if(storeData != int): #3. checking if the uder inout a not a number, if true displays in the output with statement that it not a number.
        print("That's not a number")
else: #4. else if its a number, displays in the output with the statement.
    print("its a number")
