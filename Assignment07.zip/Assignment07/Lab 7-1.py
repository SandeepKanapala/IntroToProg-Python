
# Display the current data
# The file must be created first before this will work,
#(and a+ does not work here!)
objFile = None
strUserInput = None

def WriteUserInput(File):
    print("Type in a Product I, Name and price you want to add to the file")
    print("(Enter 'Exit' to quit!)")
    while (True):
        strUserInput = input("Enter the Id, Name and Price (ex. 1,Laptop,999): ")
        if (strUserInput.lower() == "exit"):
            break
        else:
            File.write(strUserInput + "\n")
def ReadFileData(File, Message="Contents of the file"):
    print(Message)
    objFile.seek(0)
    print(File.read())



objFile = open("C:\\_PythonClass\\Assignment07\\Products.txt", "r+")#see page 193
ReadFileData(objFile,"Here is the current Data")
WriteUserInput(objFile)
ReadFileData(objFile,"Here is the current Data")
objFile.close()


# 1) Create a script that allows you to store product ids, names, and prices.
# The code will be very similar to the last example.