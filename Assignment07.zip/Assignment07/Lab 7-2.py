
# Display the current data
# The file must be created first before this will work,
#(and a+ does not work here!)
objFile = None
strUserInput = None

def WriteUserInput(File):
    try:
        print("Type in a Product I, Name and price you want to add to the file")
        print("(Enter 'Exit' to quit!)")
        while (True):
            strUserInput = input("Enter the Id, Name and Price (ex. 1,Laptop,999): ")
            if (strUserInput.lower() == "exit"):
                break
            else:
                File.write(strUserInput + "\n")
    except Exception as e:
        print("Error: " + str(e))
def ReadFileData(File, Message="Contents of the file"):
    try:
        print(Message)
        objFile.seek(0)
        print(File.read())
    except Exception as e:
        print("error:" + str(e))

try:
    objFile = open("Productszzzz.txt", "r+")
    ReadFileData(objFile,"Here is the current Data")
    WriteUserInput(objFile)
    ReadFileData(objFile,"Here is the current Data")
except Exception as e:
    print("error:" + str(e))
finally:
    if(objFile != None):objFile.close()