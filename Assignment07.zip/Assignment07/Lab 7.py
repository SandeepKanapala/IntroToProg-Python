# Read It
# Demonstrates reading from a text file

print("Opening and closing the file.")
text_file = open("read_it.txt", "r")
text_file.close()

print("\nReading the entire file at once.")
text_file = open("read_it.txt", "r")
whole_thing = text_file.read()
print(whole_thing)
text_file.close()

print("\nReading characters from the file.")
text_file = open("read_it.txt", "r")
print(text_file.read(1))
print(text_file.read(2))
print(text_file.read(3))
text_file.close()

print("\nReading the entire file into a list.")
text_file = open("read_it.txt", "r")
lines = text_file.readlines()
print(lines)
print(len(lines))
for line in lines:
    print(line)
text_file.close()


# Write It
# Demonstrates writing to a text file
# print("Creating a text file with the write() method.")
# text_file = open("write_it.txt", "w")
#
# text_file.write("Line 1\n")
# text_file.write("This is line 2\n")
# text_file.write("That makes this line 3\n")
# text_file.close()
#
# print("\nReading the newly created file.")
# text_file = open("write_it.txt", "r")
# print(text_file.read())
# text_file.close()
print("\nCreating a text file with the writelines() method.")
text_file = open("write_it.txt", "w")
lines = ["Line 1\n",
         "This is line 2\n",
         "That makes this line 3\n"]
text_file.writelines(lines)
text_file.close()

print("\nReading the newly created file.")
text_file = open("write_it.txt", "r")
print(text_file.read())
text_file.close()

input("\n\nPress the enter key to exit.")
