# Author: MyName
# When: 12/13/2018
# Purpose: Assignment 07 - Pickling
#-------------------------------------------------------------------------------
#1. create a home inventory list with product name and price
#2. add the data from the file
#3. Retrive fromt he dinary file
#-------------------------------------------------------------------------------
import pickle
#1. create a home inventory list with product name and price
name = ["xbox", "sofa"]
price = ["249", "799"]

#2. add the data from the file
file = open("test.dat", "wb") #open() function open and puts the reults into 'file'
pickle.dump(name, file) #adds the data to the file
pickle.dump(price, file)
file.close()

#3. Retrive fromt he dinary file
print("Retreiving from binary file after loading data to the file - ")
file = open("test.dat", "rb") #reads from a binary file
ProductName = pickle.load(file) #Unpickles and returns the next pickled object in file
ProductPrice = pickle.load(file)
print(ProductName,ProductPrice)
file.close()