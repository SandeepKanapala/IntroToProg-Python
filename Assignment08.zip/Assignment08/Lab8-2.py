# --- Make the class ---
class Person(object):
    """ Base Class for Personal data """

    # -------------------------------------#
    # Desc:  Contructors
    # Dev:   Kanapalas
    # Date:  12/14/2018
    # ChangeLog:(When,Who,What)
    # -------------------------------------#

    # --Fields--
    # FirstName = ""
    # LastName = ""

    # --Constructor--
    def __init__(self, FirstName, LastName):
        # Attributes
        self.FirstName = FirstName
        self.LastName = LastName


    # --Properties--

    def ToString(self):
        return self.FirstName + ","  + self.LastName

# End of class

# --- Use the class ----
# by making an object!
objP1 = Person("Bob", "Candoit")
# objP1.FirstName = "Bob"
# objP1.LastName = "Candoit"

objP2 = Person("Sue", "Alwayscan")
# objP2.FirstName = "Sue"
# objP2.LastName = "Alwaycan"

print(objP1.ToString())
print("-------------")
print(objP2.ToString())
