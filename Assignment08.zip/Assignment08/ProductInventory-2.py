# -------------------------------------#
# Desc:  Product Inventory
# Dev:   RRoot
# Date:  12/2018
# ChangeLog:12/2018,RRoot,Created Product inventory script
# -------------------------------------#
#Data
objFile = None #File Handle
strUserInput = None #A string which holds user input
class Product(object):
    """ Base Class for Product data """

    # -------------------------------------#
    # Desc:  Product Class with name
    # Dev:   SandeepK
    # Date:  12/14/2018
    # ChangeLog:12/14/2018,SandeepK,added a new product class script
    # -------------------------------------#
    # Id = ""
    # Name = ""
    # Price = ""
    #constructor
    def __init__(self, Name = ""):
        # Attributes
        # self.__Id = Id
        self.__Name = Name
        # self.__Price = Price

    # Property for product Name
    @property #gettter or accessor
    def Name(self):
        return self.__Name
    @Name.setter # setter or amulator
    def Name(self, NameValue):
        self.__Name = NameValue

    #Method to return products details
    def ProductInfo(self):
        return self.Name
    #
    def __str__(self):
        return self.ProductInfo()

class ProductDetails(Product):

    '''Base call for product details like ID and price'''
    # -------------------------------------#
    # Desc:  Product Class with Id and price
    # Dev:   SandeepK
    # Date:  12/14/2018
    # ChangeLog:12/14/2018,SandeepK,added a new product class script
    # -------------------------------------#

    def __init__(self, Id="", Name="", Price=""):
        # Attributes
        self.__Id = Id
        super(ProductDetails, self).__init__(Name)
        self.__Price = Price
    #properties
    #Product Id Property
    @property
    def Id(self):   
        return self.__Id
    @Id.setter
    def Id(self, IdValue):
        self.__Id = IdValue
    # Product Price Property
    @property
    def Price(self):
        return self.__Price
    @Price.setter
    def Price(self, PriceValue):
        self.__Price = PriceValue

        # --Methods--
    def ProductInfo(self):
        return str(self.Id) + ',' + str(self.Name) + "," + str(self.Price)

    def __str__(self):
        return self.ProductInfo()

#Processing
def WriteProductUserInput(File):
  try:
    print("Type in a Product Id, Name, and Price you want to add to the file")
    print("(Enter 'Exit' to quit!)")
    while(True):
    #ask the user to enter product details
      ProductId = input("Enter the Product Id (ex. 1): ")
      ProductName = input("Enter the Product Name (ex. ProductA): ")
      ProductPrice = input("Enter the Product Price (ex. 99.99): ")
      AllProductDetails = ProductDetails(ProductId, ProductName, ProductPrice)
      File.write(AllProductDetails.ProductInfo() + "\n") #writes the provided product details to file.
      if(input("Type 'exit' to end?").lower() == "exit"): break
  except Exception as e: # Exception class that is built in to catch all errors and print the error info.
    print("Error: " + str(e))

#Function to read data from the file
def ReadAllFileData(File, Message="Contents of File"):
  try:
    print(Message)
    File.seek(0)
    print(File.read())
  except Exception as e: # Exception class to catch all error and display the error.
    print("Error: " + str(e))

#I/O
try:
  objFile = open("Products.txt", "r+") #Opens the file in read mode.
  ReadAllFileData(objFile, "Here is the current data:")
  WriteProductUserInput(objFile)
  ReadAllFileData(objFile, "Here is this data was saved:")
except FileNotFoundError as e: # if the file is not created, throws an error that file is does not exist.
     print("Error: " + str(e) + "\n Please check the file name")
except Exception as e:
    print("Error: " + str(e))
finally:
  if(objFile != None):objFile.close() # closes the file connection.