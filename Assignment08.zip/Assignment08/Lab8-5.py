# Create a Customer Class that has a Customer Id, FirstName, and LastName properties by inheriting code from your Person class.

# --- Make the class ---
class Person(object):
    """ Base Class for Personal data """

    # -------------------------------------#
    # Desc:  Inheritance
    # Dev:   Kanapalas
    # Date:  12/14/2018
    # ChangeLog:(When,Who,What)
    # -------------------------------------#

    # --Fields--
    # FirstName = ""
    # LastName = ""

    # --Constructor--
    def __init__(self, FirstName = "", LastName = ""):
        # Attributes
        self.__FirstName = FirstName
        self.__LastName = LastName

    # --Properties--
    #FristName property
    @property #(getter or accessor)
    def FirstName(self):
        return self.__FirstName
    @FirstName.setter #(Setter or amulator)
    def FirstName(self, Value):
        self.__FirstName = Value

    #LastName property
    @property
    def LastName(self):
        return self.LastName
    @LastName.setter
    def LastName(self, Value):
        self.__LastName = Value

    def ToString(self):
        return self.__FirstName + ","  + self.__LastName

    def __str__(self):
        return self.ToString()


# End of class

# --- Use the class ----
# by making an object! 
objP1 = Person("Bob", "Candoit")
# objP1.FirstName = "Bob"
# objP1.LastName = "Candoit"

#objP2 = Person("Sue", "Alwayscan")
# objP2.FirstName = "Sue"
# objP2.LastName = "Alwaycan"

print(objP1)
print("-------------")
#print(objP2)

class Employee(Person):

    def __int__(self, ID = ""):
        self.__ID = ID

    @property
    def ID(self):
        return self.__ID
    @ID.setter
    def ID(self, Value):
        self.__ID = Value

        # --Methods--
    def ToString(self):
        # This overrides the original method (it's polymorphic)
        """Explictly returns field data"""
        strData = super().ToString()
        return str(self.ID) + ',' + strData

    def __str__(self):
        # This overrides the original method as well
        """Implictly returns field data"""
        strData = super().__str__()
        return str(self.ID) + ',' + strData
    # --End of Class --

ObjE1 = Employee("Sam", "Kanaps")
ObjE1.ID = 1
# ObjE1.FirstName = "Sam"
# ObjE1.LastName = "Kanaps"
print(ObjE1.ToString())
# print(ObjE1)
