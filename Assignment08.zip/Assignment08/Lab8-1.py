#--- Make the class ---
class Person(object):
    """ Base Class for Personal data """
    # -------------------------------------#
    # Desc:  Feilds
    # Dev:   Kanapalas
    # Date:  12/14/2018
    # ChangeLog:(When,Who,What)
    # -------------------------------------#

    # --Fields--
    FirstName = ""
    LastName = ""

    # --Constructor--
    # Attributes
    # --Properties--

    def ToString(self):
        return self.FirstName + "," + self.LastName
#End of class

# --- Use the class ----
# by making an object!
objP1 = Person()
objP1.FirstName = "Bob"
objP1.LastName = "Candoit"

objP2 = Person()
objP2.FirstName = "Sue"
objP2.LastName = "Alwaycan"

print(objP1.ToString())
print("-------------")
print(objP2.ToString())